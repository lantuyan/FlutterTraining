package com.example.chapter_9

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
